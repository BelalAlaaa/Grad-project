from flask import Flask, render_template, request, url_for, redirect
from dashboard import dashboard_bp 
from webdevelopment.trials.network import receive_sensor_data
from AI_model import process_images_in_directory
import os

app = Flask(__name__)

INPUT_DIR = 'input'
OUTPUT_DIR = 'static/predictions'

# Register the dashboard module
app.register_blueprint(dashboard_bp)

@app.route('/')
def index():
    return render_template('index.html')

# This is the route for running the YOLO model on images
@app.route('/run', methods=['POST'])
def run_yolo():
    # Trigger YOLO processing on images
    process_images_in_directory(INPUT_DIR, OUTPUT_DIR)
    return redirect(url_for('ai_model'))  # Redirect to the results page

@app.route('/results')
def ai_model():
    # List all the images in the predictions directory
    images = [
        f for f in os.listdir(OUTPUT_DIR)
        if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp'))
    ]
    return render_template('ai_model.html', images=images)

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")    

@app.route('/receive', methods=['POST'])
def receive_data():
    return receive_sensor_data(request)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
