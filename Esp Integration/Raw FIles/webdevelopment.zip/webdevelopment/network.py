from flask import request, jsonify
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import desc
from webdevelopment.database_setup import (
    SessionLocal, SensorData, Sensor, Device, UserInteraction,
    Actuator, WeightedAverageFusionData
)
from webdevelopment.weightedAverage import process_weighted_fusion

# Authentication credentials for devices
credentials = {
    "Ventilation_System_ESP": "password",
    "Irrigation_System_ESP": "password"
}

# Constants
DEFAULT_USER_ID = 5000  # Server user
TEMP_THRESHOLD = 30
HUM_THRESHOLD = 40
SOIL_MOISTURE_THRESHOLD = 30

# Actuator Names
INTAKE_SHUTTER = "intake_shutter"
WATER_PUMP = "water_pump"
VENTILATION_FAN = "ventilation_fan"

# Device IDs (you may adjust these to match your database)
Ventilation_System_ESP_ID = 1111
Irrigation_System_ESP_ID = 2222


def log_user_action(session, device_id, action, user_id):
    interaction = UserInteraction(
        DeviceID=device_id,
        # ActuatorID=None,  # Assuming no actuator is involved in this action
        Action=action,
        UserID=user_id,
        Timestamp=datetime.utcnow()
    )
    session.add(interaction)


def control_actuator(session, actuator_name, status, user_id):
    actuator = session.query(Actuator).filter_by(ActuatorName=actuator_name).first()
    if not actuator:
        actuator = Actuator(ActuatorName=actuator_name, Status=status, LastUpdated=datetime.utcnow(), UserID=user_id)
        session.add(actuator)
    else:
        actuator.Status = status
        actuator.LastUpdated = datetime.utcnow()
        actuator.UserID = user_id

    # Log who triggered this actuator (device ID used is ActuatorID here for consistency)
    log_user_action(session, device_id=actuator.ActuatorID, action=f"{actuator_name}_{status.lower()}", user_id=user_id)
    return True

def get_latest_fused_values():
    session = SessionLocal()

    try:
        # For temperature
        latest_temp = (
            session.query(WeightedAverageFusionData)
            .filter(WeightedAverageFusionData.SensorType == "temperature")
            .order_by(desc(WeightedAverageFusionData.Timestamp))
            .first()
        )

        # For humidity
        latest_hum = (
            session.query(WeightedAverageFusionData)
            .filter(WeightedAverageFusionData.SensorType == "humidity")
            .order_by(desc(WeightedAverageFusionData.Timestamp))
            .first()
        )

        return {
            "temperature": latest_temp.FusedValue if latest_temp else None,
            "humidity": latest_hum.FusedValue if latest_hum else None
        }

    finally:
        session.close()


def action_based_on_sensor(get_latest_fused_values, temperature=0, humidity=0, soil_moisture=0, user_id=DEFAULT_USER_ID):

    latest_values = get_latest_fused_values()
    temperature= latest_values["temperature"]
    humidity= latest_values["humidity"]
    session = SessionLocal()
    action_taken = "none"

    try:
        if temperature > TEMP_THRESHOLD or humidity > HUM_THRESHOLD:
            control_actuator(session, VENTILATION_FAN, "On", user_id)
            control_actuator(session, INTAKE_SHUTTER, "On", user_id)
            log_user_action(session, device_id=Ventilation_System_ESP_ID, action="ventilation_on", user_id=user_id)
            action_taken = "VENTILATION_System_on"

        elif soil_moisture < SOIL_MOISTURE_THRESHOLD:
            control_actuator(session, WATER_PUMP, "On", user_id)
            log_user_action(session, device_id=Irrigation_System_ESP_ID, action="irrigation_on", user_id=user_id)
            action_taken = "Irrigation_System_on"

        session.commit()
        return action_taken

    except Exception as e:
        session.rollback()
        print(f"[ERROR] Failed to perform action: {e}")
        return "error"

    finally:
        session.close()


def store_sensor_data(device_id, DeviceName, temperature=None, filtered_temperature=None, humidity=None, filtered_humidity=None, soil_moisture=None, filtered_soil_moisture=None):
    session = SessionLocal()

    try:
        # Ensure device exists
        device = session.query(Device).filter_by(DeviceID=device_id).first()
        if not device:
            device = Device(DeviceID=device_id, DeviceName=DeviceName, Type="ESP32", Location="Unknown", Status="Active")
            session.add(device)
            session.commit()
            session.refresh(device)

        # Fetch or create sensor for each type
        def get_or_create_sensor(sensor_type):
            sensor = (
                session.query(Sensor)
                .filter_by(DeviceID=device_id, SensorType=sensor_type)
                .first()
            )
            if not sensor:
                sensor = Sensor(DeviceID=device_id, SensorType=sensor_type, SensorIndex=0, Location="Unknown")
                session.add(sensor)
                session.commit()
                session.refresh(sensor)
            return sensor

        # Store raw & fused data
        if temperature is not None:
            sensor = get_or_create_sensor("temperature")
            session.add(SensorData(SensorID=sensor.SensorID, Value=temperature, Timestamp=datetime.utcnow()))

        if filtered_temperature is not None:
            sensor = get_or_create_sensor("temperature")
            session.add(SensorData(SensorID=sensor.SensorID, Value=filtered_temperature, Timestamp=datetime.utcnow()))

        if humidity is not None:
            sensor = get_or_create_sensor("humidity")
            session.add(SensorData(SensorID=sensor.SensorID, Value=humidity, Timestamp=datetime.utcnow()))

        if filtered_humidity is not None:
            sensor = get_or_create_sensor("humidity")
            session.add(SensorData(SensorID=sensor.SensorID, Value=filtered_humidity, Timestamp=datetime.utcnow()))

        if soil_moisture is not None:
            sensor = get_or_create_sensor("soil_moisture")
            session.add(SensorData(SensorID=sensor.SensorID, Value=soil_moisture, Timestamp=datetime.utcnow()))

        if filtered_soil_moisture is not None:
            sensor = get_or_create_sensor("soil_moisture")
            session.add(SensorData(SensorID=sensor.SensorID, Value=filtered_soil_moisture, Timestamp=datetime.utcnow()))

        session.commit()

    except Exception as e:
        session.rollback()
        print(f"[ERROR] Failed to store sensor data: {e}")
    finally:
        session.close()


def receive_sensor_data(request):
    # Basic HTTP Auth
    auth = request.authorization
    if not auth or credentials.get(auth.username) != auth.password:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid or missing JSON payload"}), 400

        DeviceID = data.get('DeviceID')
        DeviceName = data.get('DeviceName')
        temperature = data.get('temperature')
        filtered_temperature = data.get('filtered_temperature')
        humidity = data.get('humidity')
        filtered_humidity = data.get('filtered_humidity')
        soil_moisture = data.get('soil_moisture')
        filtered_soil_moisture = data.get('filtered_soil_moisture')

        # Store data
        store_sensor_data(DeviceID, DeviceName, temperature, filtered_temperature,
                          humidity, filtered_humidity, soil_moisture, filtered_soil_moisture)
        
        

        # Take action if needed
        action_result = action_based_on_sensor(DeviceName, temperature, humidity, soil_moisture)

        return jsonify({"status": "success", "action": action_result}), 200

    except Exception as e:
        print(f"[ERROR] Failed to receive/process sensor data: {e}")
        return jsonify({"error": "Internal Server Error"}), 500
