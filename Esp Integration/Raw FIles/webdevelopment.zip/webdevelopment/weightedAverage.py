from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from webdevelopment.database_setup import (
    KalmanFilterFusionData,
    WeightedAverageFusionData,
    SessionLocal
)

# Device IDs
TEMP_DEVICE_IDS = [1, 2, 3]
HUM_DEVICE_IDS = [5, 6, 7]

# Fusion weights
WEIGHTS = [0.5, 0.3, 0.2]  # Must be in same order as DeviceIDs

# Fusion delay tolerance
FUSION_WINDOW_SECONDS = 60  # 1 minute


def weighted_average_fusion(sensor_data, weights):
    fused_value = []
    for i in range(0, len(sensor_data), 3):
        subreading = sensor_data[i:i+3]
        subweight = weights[i:i+3]
        if len(subreading) == 3:
            result = sum([r * w for r, w in zip(subreading, subweight)])
            fused_value.append(result)
    return fused_value


def fetch_recent_sensor_data(session, device_ids, window_seconds):
    """Fetch the most recent Kalman-filtered readings for given device_ids within time window."""
    latest_entries = {}
    now = datetime.utcnow()
    window_start = now - timedelta(seconds=window_seconds)

    for device_id in device_ids:
        entry = session.query(KalmanFilterFusionData)\
            .filter(KalmanFilterFusionData.DeviceID == device_id)\
            .filter(KalmanFilterFusionData.Timestamp >= window_start)\
            .order_by(KalmanFilterFusionData.Timestamp.desc())\
            .first()
        if entry:
            latest_entries[device_id] = entry.FusedValue

    return latest_entries


def process_weighted_fusion():
    session: Session = SessionLocal()
    try:
        # Fetch recent readings
        temp_data = fetch_recent_sensor_data(session, TEMP_DEVICE_IDS, FUSION_WINDOW_SECONDS)
        hum_data = fetch_recent_sensor_data(session, HUM_DEVICE_IDS, FUSION_WINDOW_SECONDS)

        # Ensure all 3 sensors reported
        if len(temp_data) == 3:
            temp_values = [temp_data[dev] for dev in TEMP_DEVICE_IDS]
            fused_temp = weighted_average_fusion(temp_values, WEIGHTS)
            for value in fused_temp:
                session.add(WeightedAverageFusionData(
                    DeviceID=TEMP_DEVICE_IDS[0],  # Or a virtual ID
                    Timestamp=datetime.utcnow(),
                    FusedValue=value
                ))
            print(f"[TEMP] Fused result: {fused_temp}")
        else:
            print("[TEMP] Not all sensors reported within time window.")

        if len(hum_data) == 3:
            hum_values = [hum_data[dev] for dev in HUM_DEVICE_IDS]
            fused_hum = weighted_average_fusion(hum_values, WEIGHTS)
            for value in fused_hum:
                session.add(WeightedAverageFusionData(
                    DeviceID=HUM_DEVICE_IDS[0],  # Or a virtual ID
                    Timestamp=datetime.utcnow(),
                    FusedValue=value
                ))
            print(f"[HUM] Fused result: {fused_hum}")
        else:
            print("[HUM] Not all sensors reported within time window.")

        session.commit()
        print("Fusion process complete.")
    except Exception as e:
        session.rollback()
        print(f"[ERROR] Fusion process failed: {e}")
    finally:
        session.close()
