from sqlalchemy import (
    create_engine, Column, Integer, Float, String, DateTime, ForeignKey, Boolean
)
from sqlalchemy.orm import relationship, sessionmaker, DeclarativeBase
from datetime import datetime

# Database connection
DATABASE_URL = "sqlite:///greenhouse.db"
engine = create_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(bind=engine)

# Base class
class Base(DeclarativeBase):
    pass

# UserCredentials Table
class UserCredentials(Base):
    __tablename__ = "user_credentials"

    UserID = Column(Integer, primary_key=True)
    Username = Column(String(50), nullable=False, unique=True)
    PasswordHash = Column(String(128), nullable=False)  # Hash only
    Email = Column(String(100), nullable=False, unique=True)
    FullName = Column(String(100))
    CreatedAt = Column(DateTime, default=datetime.utcnow)
    IsActive = Column(Boolean, default=True)

    # Relationships
    interactions = relationship("UserInteraction", back_populates="user", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<UserCredentials(Username={self.Username}, Email={self.Email})>"


# Devices Table
class Device(Base):
    __tablename__ = "devices"

    DeviceID = Column(Integer, primary_key=True)
    DeviceName = Column(String(50), nullable=False)
    Location = Column(String(100))
    Status = Column(String(20))

    sensors = relationship("Sensor", back_populates="device", cascade="all, delete-orphan")
    user_interactions = relationship("UserInteraction", back_populates="device", cascade="all, delete-orphan")
    kalman_fusions = relationship("KalmanFilterFusionData", back_populates="sensor_device", cascade="all, delete-orphan")
  


# Sensors Table
class Sensor(Base):
    __tablename__ = "sensors"

    SensorID = Column(Integer, primary_key=True)
    DeviceID = Column(Integer, ForeignKey("devices.DeviceID"), nullable=False)
    SensorType = Column(String(50))
    Location = Column(String(100))
    Status = Column(String(20), default="Active")

    device = relationship("Device", back_populates="sensors")
    sensor_data = relationship("SensorData", back_populates="sensor", cascade="all, delete-orphan")
    kalmanFilterFusionData = relationship("KalmanFilterFusionData", back_populates="sensor", cascade="all, delete-orphan")


# SensorData Table
class SensorData(Base):
    __tablename__ = "sensor_data"

    DataID = Column(Integer, primary_key=True)
    SensorID = Column(Integer, ForeignKey("sensors.SensorID"), nullable=False)
    Timestamp = Column(DateTime, default=datetime.utcnow)
    Value = Column(Float, nullable=False)

    sensor = relationship("Sensor", back_populates="sensor_data")


# UserInteractions Table
class UserInteraction(Base):
    __tablename__ = "user_interactions"

    InteractionID = Column(Integer, primary_key=True)
    UserID = Column(Integer, ForeignKey("user_credentials.UserID"), nullable=False)
    DeviceID = Column(Integer, ForeignKey("devices.DeviceID"), nullable=False)
    ActuatorID = Column(Integer, ForeignKey("actuators.ActuatorID"))
    Action = Column(String(20), nullable=False)
    Timestamp = Column(DateTime, default=datetime.utcnow)

    user = relationship("UserCredentials", back_populates="interactions")
    device = relationship("Device", back_populates="user_interactions")
    actuator = relationship("Actuator", back_populates="interactions")


# Kalman Filter Fusion Table
class KalmanFilterFusionData(Base):
    __tablename__ = "kalman_filter_fusion"

    FusionID = Column(Integer, primary_key=True)
    SensorID = Column(Integer, ForeignKey("sensors.SensorID"), nullable=False)
    Timestamp = Column(DateTime, default=datetime.utcnow)
    FusedValue = Column(Float, nullable=False)

    sensor = relationship("Sensor", back_populates="kalmanFilterFusionData")
    sensor_device = relationship("Device", back_populates="kalman_fusions", viewonly=True,
                                 primaryjoin="KalmanFilterFusionData.SensorID == Sensor.SensorID",
                                 secondary="sensors")


class WeightedAverageFusionData(Base):
    __tablename__ = "weighted_average_fusion"

    FusionID = Column(Integer, primary_key=True)
    SensorType = Column(String(50), nullable=False)  # 'temperature', 'humidity', etc.
    Timestamp = Column(DateTime, default=datetime.utcnow)
    FusedValue = Column(Float, nullable=False)



# Actuators Table
class Actuator(Base):
    __tablename__ = "actuators"

    ActuatorID = Column(Integer, primary_key=True)
    ActuatorName = Column(String(50), nullable=False, unique=True)
    Status = Column(String(20), nullable=False)
    LastUpdated = Column(DateTime, default=datetime.utcnow)
    UserID = Column(Integer)

    interactions = relationship("UserInteraction", back_populates="actuator")

    def __repr__(self):
        return f"<Actuator(Name={self.ActuatorName}, Status={self.Status})>"


# Create all tables
Base.metadata.create_all(engine)
