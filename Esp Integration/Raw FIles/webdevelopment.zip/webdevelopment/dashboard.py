from flask import Blueprint, jsonify
from sqlalchemy.orm import sessionmaker
from database_setup import engine, SensorData
import pandas as pd

dashboard_bp = Blueprint("dashboard", __name__)

# Create a session
Session = sessionmaker(bind=engine)
session = Session()


def fetch_sensor_data():
    """Fetches sensor data from the database and formats it into a structured dictionary."""
    # Fetch data
    data = session.query(SensorData).all()

    if not data:
        return {"time": [], "temperature": [], "humidity": [], "soil_moisture": []}  # Return empty structure

    # Convert to list of dictionaries
    result_list = [
        {"DeviceID": d.DeviceID, "SensorType": d.SensorType, "Value": d.Value, "Timestamp": d.Timestamp}
        for d in data
    ]

    # Convert to Pandas DataFrame
    df = pd.DataFrame(result_list)

    if df.empty:
        return {"time": [], "temperature": [], "humidity": [], "soil_moisture": []}

    # Convert 'Timestamp' to datetime
    df["Timestamp"] = pd.to_datetime(df["Timestamp"])

    # Pivot the data
    df_pivot = df.pivot_table(index=["Timestamp", "DeviceID"], columns="SensorType", values="Value", aggfunc="first")

    # Rename columns explicitly
    df_pivot.rename(columns={
        "humidity": "humidity",
        "temperature": "temperature",
        "soil_moisture": "soil_moisture"
    }, inplace=True)

    # Reset index
    df_pivot.reset_index(inplace=True)

    # Rename 'Timestamp' to 'time'
    df_pivot.rename(columns={"Timestamp": "time"}, inplace=True)

    # Ensure all expected columns exist and replace NaN values with 0
    expected_columns = ["humidity", "temperature", "soil_moisture"]
    for col in expected_columns:
        df_pivot[col] = df_pivot.get(col, 0).fillna(0)  # Fix warning: Uses `.get()` safely and `.fillna(0)` without inplace

    # Convert DataFrame to dictionary
    return df_pivot.to_dict(orient="list")

@dashboard_bp.route("/data")
def data():
    """Sends the latest sensor data to the frontend."""
    real_data = fetch_sensor_data()
    return jsonify(real_data)